# Recomendações para as próximas etapas
Sistema de Vistoria Técnica de Imóveis — Correia Engenharia

Estes pontos **não foram implementados** na Etapa 2, de propósito, para não ampliar o escopo.

## 1. Evolução do relatório técnico
Hoje o relatório usa a impressão do navegador ("Imprimir / salvar PDF"). Em uma próxima etapa, estudar um módulo de relatório mais completo, com:

- numeração e identificação do relatório;
- identificação do contratante e do imóvel;
- identificação do responsável técnico, número do CREA e identificação da ART;
- logotipo da Correia Engenharia;
- objetivo da vistoria;
- metodologia efetivamente utilizada;
- resumo executivo;
- resultados por ambiente;
- relação detalhada das não conformidades;
- fotografias com legendas e identificação;
- conclusão técnica editável;
- limitações da inspeção;
- assinatura do responsável técnico;
- cabeçalho, rodapé e paginação.

Cuidados de conteúdo:
- O relatório não deve inventar informações técnicas, causas, responsabilidades ou conclusões que o profissional não tenha registrado.
- A metodologia deve refletir o que foi realmente feito na vistoria, sem afirmar ensaios ou verificações que não ocorreram.
- A conclusão técnica deve ser um campo escrito pelo responsável, nunca gerado automaticamente.

Observação técnica: a paginação, o cabeçalho e o rodapé por página exigem uma biblioteca de PDF (por exemplo, jsPDF, pdfmake ou @react-pdf/renderer) ou CSS de impressão paginada. Antes de escolher, testar com 100 fotos ou mais em celular real, por causa do uso de memória.

## 2. Catálogo de procedimentos técnicos
Os 315 critérios não possuem os campos `procedure` ou `how_to`. A seção "Como inspecionar?" mostra apenas uma orientação geral derivada do método, dos instrumentos e dos avisos do catálogo.

Desenvolver procedimentos individualizados, conforme aplicável:
- objetivo da inspeção;
- como realizar a verificação;
- ferramentas e equipamentos recomendados;
- critério de aceitação;
- condições que caracterizam uma não conformidade;
- referências normativas aplicáveis;
- cuidados e limitações da inspeção.

Esse trabalho precisa de **validação técnica específica** e não deve ser preenchido automaticamente com texto genérico. O sistema já exibe o campo `procedure` quando ele existir no JSON, então o catálogo pode crescer sem mexer no código.

## 3. Pontos técnicos observados nesta etapa (para avaliar depois)
- **Controle de edição entre abas** hoje protege as vistorias. Imóveis e ambientes ainda não têm controle de versão.
- **Fotos soltas:** se o celular fechar entre salvar a foto e gravar o vínculo, a foto pode ficar sem vínculo. A verificação de integridade detecta, mas ainda não existe uma ação de limpeza.
- **Validação das regras de aplicabilidade** (box, exaustor, chuveiro) pelo engenheiro responsável.
- **Teste em aparelhos reais** (iPhone/Safari e Android/Chrome): câmera, volume de fotos e comportamento ao fechar o navegador.
- **Biblioteca técnica editável** dentro do app (adicionar, editar, desativar critérios e vincular referências normativas).
